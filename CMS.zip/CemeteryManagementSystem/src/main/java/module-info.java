module adamnaeman.cemeterymanagementsystem {
    requires javafx.controls;
    exports adamnaeman.cemeterymanagementsystem;
}
